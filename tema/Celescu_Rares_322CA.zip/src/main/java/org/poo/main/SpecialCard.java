package org.poo.main;

import java.util.ArrayList;

public class SpecialCard extends Minion{
    public SpecialCard(int attackDamage, ArrayList<String> colors, String description, int health, int mana, String name) {
        super(attackDamage, colors, description, health, mana, name);
    }
}
